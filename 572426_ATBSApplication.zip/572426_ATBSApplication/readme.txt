
Please use the below url to launch application(ATBSApp)
http://localhost:8181/ATBSApp/#/login

DB details
Schema name: test
url: jdbc:mysql://localhost:3306/test
username: root
password: 
driverClassName: com.mysql.jdbc.Driver

Note: To run application, please Right click on project and select Run As Spring Boot APP or Java Application.